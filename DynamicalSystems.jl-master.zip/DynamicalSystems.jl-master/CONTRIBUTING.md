See https://juliadynamics.github.io/DynamicalSystems.jl/latest/contributors_guide/.
